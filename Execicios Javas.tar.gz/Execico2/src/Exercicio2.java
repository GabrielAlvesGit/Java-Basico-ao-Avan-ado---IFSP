import javax.swing.JOptionPane;

public class Exercicio2{
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Digite um número inteiro:");

        try {
            int numero = Integer.parseInt(input);

            if (numero % 5 == 0 && numero % 3 == 0) {
                JOptionPane.showMessageDialog(null, "O número É divisível por 5 e 3 ao mesmo tempo.");
            } else {
                JOptionPane.showMessageDialog(null, "O número Não é divisível por 5 e 3 ao mesmo tempo.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número inteiro válido.");
        }
    }

}