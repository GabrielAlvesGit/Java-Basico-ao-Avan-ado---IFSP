import javax.swing.JOptionPane;

public class Exercicio3 {
	  public static void main(String[] args) {
	        int numero1, numero2, numero3, numero4, soma;
		  
		       
		        numero1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
		        numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));
		        numero3 = Integer.parseInt(JOptionPane.showInputDialog("Digite o terceiro número:"));
		        numero4 = Integer.parseInt(JOptionPane.showInputDialog("Digite o quarto número:"));

		       
		        soma = calcularSomaTresMenores(numero1, numero2, numero3, numero4);

		        
		        JOptionPane.showMessageDialog(null, "A soma dos três menores números é: " + soma);
		    }

		    
		    public static int calcularSomaTresMenores(int num1, int num2, int num3, int num4) {
		        int[] numeros = { num1, num2, num3, num4 };
		        java.util.Arrays.sort(numeros); 
		        return numeros[0] + numeros[1] + numeros[2];
		    }
	
}
