import javax.swing.JOptionPane;


public class Exercicio4 {
    
    private int dia;
    private char mes;

    public static void main(String[] args) {
        Exercicio4 exercicio = new Exercicio4();

      
        exercicio.dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o Dia:"));
        exercicio.mes = JOptionPane.showInputDialog("Digite o Mês:").charAt(1); 

        
        JOptionPane.showMessageDialog(null, "Você digitou o dia: " + exercicio.dia + " e o mês: " + exercicio.mes);
    }
}
